/**
 * Prueba de la clase Problema
 */
public class ProblemaPrueba {
   public static void main(String args[]){
      Problema ejemplo = new Problema("./data/small10.tsp");
      System.out.println(ejemplo.toString_funcional());
   }
}
