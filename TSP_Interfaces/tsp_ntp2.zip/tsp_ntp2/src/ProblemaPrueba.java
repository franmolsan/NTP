public class ProblemaPrueba {
    public static void main (String args []){
        Problema ejemplo = new Problema("./data/berlin52.tsp");
        System.out.println(ejemplo);
    }
}
