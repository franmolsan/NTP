/**
 * Clase
 */
public class CiudadPrueba {

    /**
     * Método main para pruebas
     * @param args
     */
    public static void main (String args[]){
        Ciudad ciudad1; // aquí no hay ningún objeto, ya que  ciudad1 es una variable de referencia
        ciudad1 = new Ciudad("Granada", 36.24, 11.17); // aquí sí se crea un objeto.
    }
}
